﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class map2 : Form
    {
        public map2()
        {
            InitializeComponent();
        }

        private void map2_Load(object sender, EventArgs e)
        {
            //System.Drawing.Drawing2D.GraphicsPath Button_Path = new System.Drawing.Drawing2D.GraphicsPath();
            //Button_Path.AddEllipse(0, 0, this.button2.Width, this.button2.Height);
            //Region Button_Region = new Region(Button_Path);
            //this.button2.Region = Button_Region;
            //button2.FlatAppearance.BorderSize = 0; button2.FlatStyle = FlatStyle.Flat;

            //System.Drawing.Drawing2D.GraphicsPath Button_Path1 = new System.Drawing.Drawing2D.GraphicsPath();
            //Button_Path.AddEllipse(0, 0, this.button1.Width, this.button1.Height);
            //Region Button_Region1 = new Region(Button_Path);
            //this.button1.Region = Button_Region;
            //button1.FlatAppearance.BorderSize = 0; button1.FlatStyle = FlatStyle.Flat;

            //System.Drawing.Drawing2D.GraphicsPath Button_Path3 = new System.Drawing.Drawing2D.GraphicsPath();
            //Button_Path.AddEllipse(0, 0, this.button3.Width, this.button3.Height);
            //Region Button_Region3 = new Region(Button_Path);
            //this.button3.Region = Button_Region;
            //button3.FlatAppearance.BorderSize = 0; button3.FlatStyle = FlatStyle.Flat;



        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 Form5 = new Form5();
            Form5.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Sudoku LoginForm = new Sudoku();
            LoginForm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 Form4 = new Form4();
            Form4.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 Form6 = new Form6();
            Form6.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
